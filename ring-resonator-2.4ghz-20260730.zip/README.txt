# Fabrication Notes

- IPC spec: IPC6012F class 2
- Surface finish: ENIG
- Solder mask color: Green
- Silk screen color: White
- Impedance control is necessary between Top Layer (GTL) and Bottom Layer (GBL).  GBL is the reference.  Impedance control type: microstrip, target impedance: 50 Ohms, width: 3.41 mm.
